# Generated from trabalhoFinal.g4 by ANTLR 4.9
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .trabalhoFinalParser import trabalhoFinalParser
else:
    from trabalhoFinalParser import trabalhoFinalParser

# This class defines a complete listener for a parse tree produced by trabalhoFinalParser.
class trabalhoFinalListener(ParseTreeListener):

    # Enter a parse tree produced by trabalhoFinalParser#vazio.
    def enterVazio(self, ctx:trabalhoFinalParser.VazioContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#vazio.
    def exitVazio(self, ctx:trabalhoFinalParser.VazioContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#prog.
    def enterProg(self, ctx:trabalhoFinalParser.ProgContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#prog.
    def exitProg(self, ctx:trabalhoFinalParser.ProgContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#decVarConst.
    def enterDecVarConst(self, ctx:trabalhoFinalParser.DecVarConstContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#decVarConst.
    def exitDecVarConst(self, ctx:trabalhoFinalParser.DecVarConstContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#tipo.
    def enterTipo(self, ctx:trabalhoFinalParser.TipoContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#tipo.
    def exitTipo(self, ctx:trabalhoFinalParser.TipoContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#listaIds.
    def enterListaIds(self, ctx:trabalhoFinalParser.ListaIdsContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#listaIds.
    def exitListaIds(self, ctx:trabalhoFinalParser.ListaIdsContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#listaAtrib.
    def enterListaAtrib(self, ctx:trabalhoFinalParser.ListaAtribContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#listaAtrib.
    def exitListaAtrib(self, ctx:trabalhoFinalParser.ListaAtribContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#decFunc.
    def enterDecFunc(self, ctx:trabalhoFinalParser.DecFuncContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#decFunc.
    def exitDecFunc(self, ctx:trabalhoFinalParser.DecFuncContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#retornoFuncao.
    def enterRetornoFuncao(self, ctx:trabalhoFinalParser.RetornoFuncaoContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#retornoFuncao.
    def exitRetornoFuncao(self, ctx:trabalhoFinalParser.RetornoFuncaoContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#main.
    def enterMain(self, ctx:trabalhoFinalParser.MainContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#main.
    def exitMain(self, ctx:trabalhoFinalParser.MainContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#comandos.
    def enterComandos(self, ctx:trabalhoFinalParser.ComandosContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#comandos.
    def exitComandos(self, ctx:trabalhoFinalParser.ComandosContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#imprime.
    def enterImprime(self, ctx:trabalhoFinalParser.ImprimeContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#imprime.
    def exitImprime(self, ctx:trabalhoFinalParser.ImprimeContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#entrada.
    def enterEntrada(self, ctx:trabalhoFinalParser.EntradaContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#entrada.
    def exitEntrada(self, ctx:trabalhoFinalParser.EntradaContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#impressao.
    def enterImpressao(self, ctx:trabalhoFinalParser.ImpressaoContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#impressao.
    def exitImpressao(self, ctx:trabalhoFinalParser.ImpressaoContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#forLoop.
    def enterForLoop(self, ctx:trabalhoFinalParser.ForLoopContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#forLoop.
    def exitForLoop(self, ctx:trabalhoFinalParser.ForLoopContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#ifElse.
    def enterIfElse(self, ctx:trabalhoFinalParser.IfElseContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#ifElse.
    def exitIfElse(self, ctx:trabalhoFinalParser.IfElseContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#verificacao.
    def enterVerificacao(self, ctx:trabalhoFinalParser.VerificacaoContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#verificacao.
    def exitVerificacao(self, ctx:trabalhoFinalParser.VerificacaoContext):
        pass


    # Enter a parse tree produced by trabalhoFinalParser#expressao.
    def enterExpressao(self, ctx:trabalhoFinalParser.ExpressaoContext):
        pass

    # Exit a parse tree produced by trabalhoFinalParser#expressao.
    def exitExpressao(self, ctx:trabalhoFinalParser.ExpressaoContext):
        pass



del trabalhoFinalParser