const String caio = "222-85@#$";

main(){
	input("Digite seu nome: ");
    print("Hello ", "world");
}